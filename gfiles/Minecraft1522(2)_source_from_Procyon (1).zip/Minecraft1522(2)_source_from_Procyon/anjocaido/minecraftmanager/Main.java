// 
// Decompiled by Procyon v0.5.36
// 

package anjocaido.minecraftmanager;

public class Main
{
    public static void main(final String[] args) {
        new MinecraftBackupManager().setVisible(true);
    }
}
